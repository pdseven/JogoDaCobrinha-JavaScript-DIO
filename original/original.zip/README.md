# JogoDaCobrinha-JavaScript-DIO
Digital Innovation One, Desafio prático: Recriando o jogo da cobrinha com JavaScript
